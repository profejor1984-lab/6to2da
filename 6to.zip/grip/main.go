package main

import (
	_ "embed"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math"
	"math/rand"
	"net"
	"net/http"
	"sort"
	"sync"
	"time"
)

//go:embed phone.html
var phoneHTML []byte

//go:embed tv.html
var tvHTML []byte

const CAP = 12  // discos máximos por celular
const MINPH = 3 // con solo el disco de arriba hacen falta al menos 3 pilas

var palette = []string{"#e53935", "#1e66e0", "#43a047", "#fdd835", "#8e44ad", "#fb8c00"}

type phone struct {
	id    string
	conn  *wsConn
	stack []int
	ready bool
}

type move struct{ a, k, b, c int } // sacar el disco k (color c) del celular a y llevarlo al b

type Hub struct {
	mu       sync.Mutex
	phones   []*phone // el índice es la posición, de izquierda a derecha
	tvs      map[*wsConn]bool
	phase    string // idle | thinking | running | done
	gen      int    // cambia al reiniciar: cancela el espectáculo en curso
	clawFrac float64
}

func (h *Hub) kColors() int {
	n := len(h.phones)
	if n < 2 {
		n = 2
	}
	if n > len(palette) {
		n = len(palette)
	}
	return n
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}

// ---------- Planificador ----------
// Cada color tiene un celular "de su casa"; cada disco ajeno se lleva directo a su casa
// (la garra puede tomarlo de cualquier lugar de la pila).

func homes(st [][]int, K int) []int {
	n := len(st)
	cnt := make([][]int, n)
	for p := range st {
		cnt[p] = make([]int, K)
		for _, c := range st[p] {
			cnt[p][c]++
		}
	}
	best, cur, bestH := -1, make([]int, K), make([]int, K)
	used := make([]bool, n)
	var rec func(c, sum int)
	rec = func(c, sum int) {
		if c == K {
			if sum > best {
				best = sum
				copy(bestH, cur)
			}
			return
		}
		for p := 0; p < n; p++ {
			if !used[p] {
				used[p] = true
				cur[c] = p
				rec(c+1, sum+cnt[p][c])
				used[p] = false
			}
		}
	}
	rec(0, 0)
	return bestH
}

// Solo se mueve el disco de arriba de una pila a otra. Se "purifica" un celular a la vez:
// se sacan los discos que estorban (se dejan en otro celular desordenado) hasta que solo
// queden discos de su color; los celulares ya limpios nunca se tocan.
func attempt(st0 [][]int, hc []int) []move {
	n := len(st0)
	s := make([][]int, n)
	for i := range st0 {
		s[i] = append([]int(nil), st0[i]...)
	}
	var mv []move
	clean := func(p int) bool {
		for _, d := range s[p] {
			if d != hc[p] {
				return false
			}
		}
		return true
	}
	block := func(p int) int {
		for k, d := range s[p] {
			if d != hc[p] {
				return len(s[p]) - k
			}
		}
		return 0
	}
	phoneOf := func(c int) int {
		for p, x := range hc {
			if x == c {
				return p
			}
		}
		return -1
	}
	do := func(a, b int) {
		k := len(s[a]) - 1
		c := s[a][k]
		mv = append(mv, move{a, k, b, c})
		s[a] = s[a][:k]
		s[b] = append(s[b], c)
	}
	cur := -1
	for it := 0; it < 300; it++ {
		all := true
		for p := 0; p < n; p++ {
			if !clean(p) {
				all = false
			}
		}
		if all {
			return mv
		}
		var safe [][2]int
		for a := 0; a < n; a++ {
			if len(s[a]) == 0 || clean(a) {
				continue
			}
			h := phoneOf(s[a][len(s[a])-1])
			if h >= 0 && h != a && clean(h) && len(s[h]) < CAP {
				safe = append(safe, [2]int{a, h})
			}
		}
		if len(safe) > 0 {
			m := safe[rand.Intn(len(safe))]
			do(m[0], m[1])
			continue
		}
		if cur < 0 || clean(cur) {
			var dirty []int
			key := map[int]int{}
			for p := 0; p < n; p++ {
				if !clean(p) {
					dirty = append(dirty, p)
					key[p] = block(p)*4 + rand.Intn(3)
				}
			}
			sort.Slice(dirty, func(i, j int) bool { return key[dirty[i]] < key[dirty[j]] })
			i := rand.Intn(2)
			if i >= len(dirty) {
				i = len(dirty) - 1
			}
			cur = dirty[i]
		}
		var room, dirtyRoom []int
		for b := 0; b < n; b++ {
			if b != cur && len(s[b]) < CAP {
				room = append(room, b)
				if !clean(b) {
					dirtyRoom = append(dirtyRoom, b)
				}
			}
		}
		pool := room
		if len(dirtyRoom) > 0 {
			pool = dirtyRoom
		}
		if len(pool) == 0 {
			return nil
		}
		do(cur, pool[rand.Intn(len(pool))])
	}
	return nil
}

// makePlan devuelve el plan más corto de varios intentos (nil si no encuentra ninguno).
func makePlan(st [][]int, K int) []move {
	home := homes(st, K) // home[color] = celular
	hc := make([]int, len(st))
	for i := range hc {
		hc[i] = -1
	}
	for c, p := range home {
		hc[p] = c
	}
	var best []move
	for i := 0; i < 60; i++ {
		if r := attempt(st, hc); r != nil && (best == nil || len(r) < len(best)) {
			best = r
		}
	}
	return best
}

// ---------- Estado ----------

func (h *Hub) stacks() [][]int {
	s := make([][]int, len(h.phones))
	for i, p := range h.phones {
		s[i] = p.stack
	}
	return s
}

func (h *Hub) validLocked() bool {
	if len(h.phones) < MINPH {
		return true
	}
	cnt := make([]int, h.kColors())
	for _, p := range h.phones {
		for _, c := range p.stack {
			cnt[c]++
		}
	}
	for _, n := range cnt {
		if n == 0 || n > CAP-2 {
			return false
		}
	}
	minMoves := len(h.phones) + 1 // que haya suficiente desorden para que valga la pena verlo
	p := makePlan(h.stacks(), h.kColors())
	return p != nil && len(p) >= minMoves
}

func (h *Hub) randomizeLocked(only int) {
	K := h.kColors()
	for try := 0; try < 300; try++ {
		for i, p := range h.phones {
			if only < 0 || i == only {
				s := make([]int, 2+rand.Intn(4))
				for j := range s {
					s[j] = rand.Intn(K)
				}
				p.stack = s
			}
		}
		if h.validLocked() {
			return
		}
	}
}

func (h *Hub) resetLocked() {
	h.gen++
	h.phase = "idle"
	h.clawFrac = 0.5
	for _, p := range h.phones {
		p.ready = false
	}
	h.randomizeLocked(-1)
	h.tvSend(map[string]any{"t": "reset"})
}

func (h *Hub) online() (on, rd int) {
	for _, p := range h.phones {
		if p.conn != nil {
			on++
			if p.ready {
				rd++
			}
		}
	}
	return
}

func (h *Hub) tvSend(v any) {
	b, _ := json.Marshal(v)
	for c := range h.tvs {
		if c.write(1, b) != nil {
			delete(h.tvs, c)
			c.c.Close()
		}
	}
}

func (h *Hub) sendStackLocked(i int) {
	p := h.phones[i]
	if p.conn == nil {
		return
	}
	cells := p.stack
	if cells == nil {
		cells = []int{}
	}
	on, _ := h.online()
	b, _ := json.Marshal(map[string]any{"t": "stack", "cells": cells, "palette": palette[:h.kColors()],
		"pos": i, "total": len(h.phones), "phase": h.phase, "ready": p.ready, "online": on})
	p.conn.write(1, b)
}

func (h *Hub) pushLocked() {
	for i := range h.phones {
		h.sendStackLocked(i)
	}
	on, rd := h.online()
	h.tvSend(map[string]any{"t": "status", "n": len(h.phones), "online": on, "ready": rd, "phase": h.phase})
}

// ---------- El espectáculo ----------

func (h *Hub) sendMoveLocked(m move) time.Duration {
	n := len(h.phones)
	fr := func(i int) float64 { return (float64(i) + .5) / float64(n) }
	dA := 300 + 900*math.Abs(fr(m.a)-h.clawFrac)
	dB := 300 + 900*math.Abs(fr(m.b)-fr(m.a))
	// viaje, bajar, agarrar, subir, viaje, bajar, soltar, volver (ms)
	d := []int{int(dA), 280, 300, 280, int(dB), 280, 300, 250}
	t2 := d[0] + d[1]
	t6 := t2 + d[2] + d[3] + d[4] + d[5]
	h.clawFrac = fr(m.b)
	h.tvSend(map[string]any{"t": "move", "a": m.a, "b": m.b, "c": m.c, "hex": palette[m.c], "n": n, "d": d})
	if pa := h.phones[m.a]; pa.conn != nil {
		b, _ := json.Marshal(map[string]any{"t": "abduct", "k": m.k, "ms": 500, "at": t2 - 500})
		pa.conn.write(1, b)
	}
	if pb := h.phones[m.b]; pb.conn != nil {
		b, _ := json.Marshal(map[string]any{"t": "drop", "c": m.c, "ms": 500, "at": t6 + 200})
		pb.conn.write(1, b)
	}
	return time.Duration(t6+d[6]+d[7]) * time.Millisecond
}

func (h *Hub) applyMoveLocked(m move) {
	a, b := h.phones[m.a], h.phones[m.b]
	if m.k < len(a.stack) {
		a.stack = append(a.stack[:m.k], a.stack[m.k+1:]...)
	}
	b.stack = append(b.stack, m.c)
	h.sendStackLocked(m.a)
	h.sendStackLocked(m.b)
}

func (h *Hub) startShowLocked() {
	h.phase = "thinking"
	h.gen++
	gen := h.gen
	h.pushLocked()
	h.tvSend(map[string]any{"t": "think", "ms": 1500})
	go func() {
		time.Sleep(1500 * time.Millisecond)
		h.mu.Lock()
		if h.gen != gen {
			h.mu.Unlock()
			return
		}
		h.phase = "running"
		plan := makePlan(h.stacks(), h.kColors())
		if plan == nil { // no debería pasar: se vuelve a mezclar todo
			h.resetLocked()
			h.pushLocked()
			h.mu.Unlock()
			return
		}
		h.pushLocked()
		h.mu.Unlock()
		for _, m := range plan {
			h.mu.Lock()
			if h.gen != gen {
				h.mu.Unlock()
				return
			}
			dur := h.sendMoveLocked(m)
			h.mu.Unlock()
			time.Sleep(dur + 150*time.Millisecond)
			h.mu.Lock()
			if h.gen != gen {
				h.mu.Unlock()
				return
			}
			h.applyMoveLocked(m)
			h.mu.Unlock()
		}
		h.mu.Lock()
		if h.gen == gen {
			h.phase = "done"
			for _, p := range h.phones {
				p.ready = false
			}
			h.pushLocked()
		}
		h.mu.Unlock()
	}()
}

func (h *Hub) maybeStartLocked() {
	on, rd := h.online()
	if h.phase == "idle" && on >= MINPH && rd == on {
		h.startShowLocked()
	}
}

// ---------- Conexiones ----------

func (h *Hub) attach(id string, c *wsConn) *phone {
	h.mu.Lock()
	defer h.mu.Unlock()
	var p *phone
	for _, x := range h.phones {
		if x.id == id {
			p = x
		}
	}
	isNew := p == nil
	if isNew {
		p = &phone{id: id}
		h.phones = append(h.phones, p)
	}
	old := p.conn
	p.conn = c
	if old != nil {
		old.c.Close()
	}
	if isNew {
		h.resetLocked() // cambió la cantidad de celulares: nuevos colores y pilas
	}
	h.pushLocked()
	return p
}

func (h *Hub) detach(p *phone, c *wsConn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if p.conn == c {
		p.conn = nil
		p.ready = false
		h.pushLocked()
	}
}

type cmdMsg struct {
	Cmd string `json:"cmd"`
}

func (h *Hub) phoneCmd(p *phone, cmd string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	switch cmd {
	case "shuffle":
		if h.phase == "thinking" || h.phase == "running" {
			return
		}
		h.phase = "idle"
		for _, q := range h.phones {
			q.ready = false
		}
		for i, q := range h.phones {
			if q == p {
				h.randomizeLocked(i)
			}
		}
		h.pushLocked()
	case "ready":
		if h.phase != "idle" || len(h.phones) < MINPH {
			return
		}
		p.ready = !p.ready
		h.pushLocked()
		h.maybeStartLocked()
	}
}

func (h *Hub) tvCmd(cmd string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	switch cmd {
	case "start": // Espacio: empezar sin esperar a que todos toquen Listo
		on, _ := h.online()
		if h.phase == "idle" && on >= MINPH {
			h.startShowLocked()
		}
	case "reset": // R: mezclar todo de nuevo
		h.resetLocked()
		h.pushLocked()
	case "forget": // F: olvidar celulares desconectados
		var keep []*phone
		for _, p := range h.phones {
			if p.conn != nil {
				keep = append(keep, p)
			}
		}
		h.phones = keep
		h.resetLocked()
		h.pushLocked()
	}
}

func main() {
	addr := flag.String("addr", ":8080", "dirección de escucha")
	flag.Parse()
	hub := &Hub{tvs: map[*wsConn]bool{}, phase: "idle", clawFrac: .5}

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(phoneHTML)
	})
	mux.HandleFunc("/tv", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(tvHTML)
	})
	mux.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		isTV := r.URL.Query().Get("role") == "tv"
		id := r.URL.Query().Get("id")
		if !isTV && (id == "" || len(id) > 40) {
			http.Error(w, "id inválido", http.StatusBadRequest)
			return
		}
		c, err := upgrade(w, r)
		if err != nil {
			return
		}
		if isTV {
			hub.mu.Lock()
			hub.tvs[c] = true
			hub.pushLocked()
			hub.mu.Unlock()
			c.loop(func(p []byte) {
				var m cmdMsg
				if json.Unmarshal(p, &m) == nil {
					hub.tvCmd(m.Cmd)
				}
			})
			hub.mu.Lock()
			delete(hub.tvs, c)
			hub.mu.Unlock()
			return
		}
		p := hub.attach(id, c)
		c.loop(func(b []byte) {
			var m cmdMsg
			if json.Unmarshal(b, &m) == nil {
				hub.phoneCmd(p, m.Cmd)
			}
		})
		hub.detach(p, c)
	})

	fmt.Println("Garra y celulares")
	for _, ip := range localIPs() {
		fmt.Printf("  Celulares:  http://%s%s/\n  TV:         http://%s%s/tv   (teclas: Espacio = empezar, R = mezclar, F = olvidar desconectados)\n", ip, *addr, ip, *addr)
	}
	log.Fatal(http.ListenAndServe(*addr, mux))
}

func localIPs() []string {
	var out []string
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if ipn, ok := a.(*net.IPNet); ok && !ipn.IP.IsLoopback() && ipn.IP.To4() != nil {
			out = append(out, ipn.IP.String())
		}
	}
	if len(out) == 0 {
		out = []string{"localhost"}
	}
	return out
}
