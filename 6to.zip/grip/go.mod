module garragroup

go 1.21
