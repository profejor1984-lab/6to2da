module cubosdistribuido

go 1.21
