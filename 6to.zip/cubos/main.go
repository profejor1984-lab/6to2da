package main

import (
	_ "embed"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"net"
	"net/http"
	"sync"
	"time"
)

//go:embed phone.html
var phoneHTML []byte

//go:embed screen.html
var screenHTML []byte

// El orden de esta lista ES el orden final: los cubitos quedan agrupados así.
// Con N colores se usan los primeros N.
var palette = []struct{ Name, Hex string }{
	{"rojo", "#e53935"}, {"verde", "#43a047"}, {"azul", "#1e4fd8"}, {"amarillo", "#fdd835"},
	{"violeta", "#8e24aa"}, {"naranja", "#fb8c00"}, {"celeste", "#29b6f6"}, {"rosa", "#ec407a"},
}

// ---------- Estado centralizado ----------

type packet struct {
	start  int
	orig   []int
	sorted []int  // nil hasta que el celular lo devuelve
	state  string // pending | assigned | done
	worker int    // número visible del celular (0 = ninguno)
}

type worker struct {
	id   string // identificador estable guardado en el navegador del celular
	n    int    // número visible (1, 2, 3…)
	conn *wsConn
	busy int // paquete que está ordenando (-1 = libre)
	done int // paquetes entregados
}

type Hub struct {
	mu      sync.Mutex
	workers []*worker
	screens map[*wsConn]bool

	rows, cols, ncolors, pktSize int
	matrix                       []int
	packets                      []*packet

	phase string // idle | ready | distributing | merging | done
	// fusión final (la hace la computadora)
	heads         []int
	result        []int
	outN          int
	take, takeIdx int
	paused        bool

	stepMs  int // velocidad de la fusión
	workMs  int // velocidad del ordenamiento en los celulares
	logLine string
}

func NewHub() *Hub {
	return &Hub{
		screens: map[*wsConn]bool{},
		rows:    6, cols: 10, ncolors: 4, pktSize: 10,
		phase: "idle", take: -1, stepMs: 250, workMs: 80,
		logLine: "Genera una matriz para empezar.",
	}
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func (h *Hub) total() int { return len(h.matrix) }

func (h *Hub) generateLocked(rows, cols, nc, pkt int) {
	rows, cols = clamp(rows, 1, 20), clamp(cols, 1, 20)
	if rows*cols < 2 {
		cols = 2
	}
	nc = clamp(nc, 2, len(palette))
	total := rows * cols
	pkt = clamp(pkt, 2, 60)
	if pkt > total {
		pkt = total
	}
	h.rows, h.cols, h.ncolors, h.pktSize = rows, cols, nc, pkt
	for try := 0; try < 50; try++ {
		m := make([]int, total)
		sorted := true
		for i := range m {
			m[i] = rand.Intn(nc)
			if i > 0 && m[i-1] > m[i] {
				sorted = false
			}
		}
		h.matrix = m
		if !sorted {
			break
		}
	}
	h.resetLocked(fmt.Sprintf("Matriz de %d×%d lista (%d colores, paquetes de %d).", rows, cols, nc, pkt))
}

// resetLocked vuelve a dejar la MISMA matriz desordenada y sin repartir.
func (h *Hub) resetLocked(msg string) {
	h.packets = nil
	h.heads, h.result = nil, nil
	h.outN, h.take, h.takeIdx, h.paused = 0, -1, 0, false
	for _, w := range h.workers {
		w.busy, w.done = -1, 0
	}
	if h.matrix == nil {
		h.phase = "idle"
	} else {
		h.phase = "ready"
		for s := 0; s < len(h.matrix); s += h.pktSize {
			e := s + h.pktSize
			if e > len(h.matrix) {
				e = len(h.matrix)
			}
			h.packets = append(h.packets, &packet{
				start: s, orig: append([]int(nil), h.matrix[s:e]...), state: "pending",
			})
		}
	}
	h.logLine = msg
	h.sendIdleLocked("")
}

func (h *Hub) startLocked() {
	if h.phase != "ready" {
		h.logLine = "Primero genera una matriz (o usa Repetir)."
		return
	}
	h.phase = "distributing"
	h.logLine = fmt.Sprintf("Repartiendo %d paquetes entre los celulares…", len(h.packets))
	h.dispatchLocked()
}

// ---------- Reparto de paquetes ----------

func (h *Hub) nextPendingLocked() int {
	for i, p := range h.packets {
		if p.state == "pending" {
			return i
		}
	}
	return -1
}

func (h *Hub) dispatchLocked() {
	if h.phase != "distributing" {
		return
	}
	for _, w := range h.workers {
		if w.conn == nil || w.busy >= 0 {
			continue
		}
		pid := h.nextPendingLocked()
		if pid < 0 {
			break
		}
		h.assignLocked(w, pid)
	}
}

// dispatchKeepLogLocked reparte sin pisar el aviso (reconexión, error) que acaba de escribirse.
func (h *Hub) dispatchKeepLogLocked() {
	msg := h.logLine
	h.dispatchLocked()
	h.logLine = msg
}

func (h *Hub) assignLocked(w *worker, pid int) {
	p := h.packets[pid]
	hex := make([]string, h.ncolors)
	for i := range hex {
		hex[i] = palette[i].Hex
	}
	b, _ := json.Marshal(map[string]any{
		"t": "job", "job": pid, "jobs": len(h.packets), "worker": w.n,
		"cells": p.orig, "palette": hex, "stepMs": h.workMs,
	})
	if err := w.conn.write(1, b); err != nil {
		return // la conexión se está cayendo; el paquete sigue pendiente
	}
	p.state, p.worker = "assigned", w.n
	w.busy = pid
	h.logLine = fmt.Sprintf("Paquete %d → celular %d", pid+1, w.n)
}

func (h *Hub) requeueLocked(w *worker, why string) {
	if w.busy < 0 {
		return
	}
	p := h.packets[w.busy]
	p.state, p.worker = "pending", 0
	h.logLine = fmt.Sprintf("Celular %d: %s. El paquete %d vuelve a la fila.", w.n, why, w.busy+1)
	w.busy = -1
}

func validSorted(orig, cells []int, nc int) bool {
	if len(cells) != len(orig) {
		return false
	}
	count := make([]int, nc)
	for _, v := range orig {
		count[v]++
	}
	for i, v := range cells {
		if v < 0 || v >= nc || (i > 0 && cells[i-1] > v) {
			return false
		}
		count[v]--
	}
	for _, c := range count {
		if c != 0 {
			return false
		}
	}
	return true
}

func (h *Hub) doneLocked(w *worker, job int, cells []int) {
	if h.phase != "distributing" || job < 0 || job >= len(h.packets) {
		return
	}
	p := h.packets[job]
	if p.state != "assigned" || p.worker != w.n {
		return
	}
	if !validSorted(p.orig, cells, h.ncolors) {
		h.requeueLocked(w, "devolvió un paquete mal ordenado")
		h.dispatchKeepLogLocked()
		return
	}
	p.sorted, p.state = cells, "done"
	w.busy = -1
	w.done++
	h.logLine = fmt.Sprintf("Celular %d devolvió el paquete %d ordenado.", w.n, job+1)
	for _, q := range h.packets {
		if q.state != "done" {
			h.dispatchLocked()
			return
		}
	}
	h.beginMergeLocked()
}

// ---------- Fusión final: le toca a la computadora ----------

func (h *Hub) beginMergeLocked() {
	h.phase = "merging"
	h.heads = make([]int, len(h.packets))
	h.result = make([]int, h.total())
	for i := range h.result {
		h.result[i] = -1
	}
	h.outN, h.take, h.paused = 0, -1, false
	h.logLine = "Volvieron todos los paquetes. Ahora la computadora los fusiona."
	h.sendIdleLocked("La computadora está fusionando los paquetes…")
}

// Toma, entre las "cabezas" de todos los paquetes ordenados, el cubito más chico.
func (h *Hub) mergeStepLocked() {
	if h.phase != "merging" {
		return
	}
	best := -1
	for i, p := range h.packets {
		if h.heads[i] >= len(p.sorted) {
			continue
		}
		if best < 0 || p.sorted[h.heads[i]] < h.packets[best].sorted[h.heads[best]] {
			best = i
		}
	}
	if best < 0 {
		return
	}
	v := h.packets[best].sorted[h.heads[best]]
	h.result[h.outN] = v
	h.take, h.takeIdx = best, h.heads[best]
	h.heads[best]++
	h.outN++
	h.logLine = fmt.Sprintf("Fusión: el %s del paquete %d pasa al resultado (%d/%d)", palette[v].Name, best+1, h.outN, h.total())
	if h.outN == h.total() {
		h.phase = "done"
		h.logLine = "¡Todo ordenado!"
		h.sendIdleLocked("¡Listo! Todo ordenado.")
	}
}

// ---------- Comunicación ----------

func (h *Hub) sendIdleLocked(msg string) {
	b, _ := json.Marshal(map[string]any{"t": "idle", "msg": msg})
	for _, w := range h.workers {
		if w.conn != nil {
			w.conn.write(1, b)
		}
	}
}

type pktView struct {
	Start  int    `json:"start"`
	Len    int    `json:"len"`
	State  string `json:"state"`
	Worker int    `json:"worker"`
	Sorted []int  `json:"sorted"`
}

func (h *Hub) pushLocked() {
	pk := make([]pktView, len(h.packets))
	doneN := 0
	for i, p := range h.packets {
		pk[i] = pktView{p.start, len(p.orig), p.state, p.worker, p.sorted}
		if p.state == "done" {
			doneN++
		}
	}
	ws := make([]map[string]any, len(h.workers))
	for i, w := range h.workers {
		ws[i] = map[string]any{"n": w.n, "online": w.conn != nil, "busy": w.busy, "done": w.done}
	}
	pal := make([]map[string]string, h.ncolors)
	for i := range pal {
		pal[i] = map[string]string{"name": palette[i].Name, "hex": palette[i].Hex}
	}
	snap, _ := json.Marshal(map[string]any{
		"t": "state", "phase": h.phase, "rows": h.rows, "cols": h.cols, "pkt": h.pktSize,
		"ncolors": h.ncolors, "palette": pal, "matrix": h.matrix, "packets": pk,
		"workers": ws, "heads": h.heads, "result": h.result, "outN": h.outN,
		"paused": h.paused, "stepMs": h.stepMs, "workMs": h.workMs,
		"doneN": doneN, "log": h.logLine,
	})
	for c := range h.screens {
		if err := c.write(1, snap); err != nil {
			delete(h.screens, c)
			c.c.Close()
		}
	}
}

func (h *Hub) attach(id string, c *wsConn) *worker {
	h.mu.Lock()
	defer h.mu.Unlock()
	var w *worker
	for _, x := range h.workers {
		if x.id == id {
			w = x
			break
		}
	}
	if w == nil {
		w = &worker{id: id, n: len(h.workers) + 1, busy: -1}
		h.workers = append(h.workers, w)
	}
	old := w.conn
	w.conn = c
	if old != nil {
		old.c.Close()
	}
	h.requeueLocked(w, "se reconectó") // la página recargada perdió su trabajo
	b, _ := json.Marshal(map[string]any{"t": "hello", "worker": w.n})
	c.write(1, b)
	h.dispatchKeepLogLocked()
	h.pushLocked()
	return w
}

func (h *Hub) detach(w *worker, c *wsConn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if w.conn == c {
		w.conn = nil
		h.requeueLocked(w, "se desconectó")
		h.dispatchKeepLogLocked()
		h.pushLocked()
	}
}

type cmdMsg struct {
	Cmd    string `json:"cmd"`
	Ms     int    `json:"ms"`
	Rows   int    `json:"rows"`
	Cols   int    `json:"cols"`
	Colors int    `json:"colors"`
	Pkt    int    `json:"pkt"`
	Job    int    `json:"job"`
	Cells  []int  `json:"cells"`
}

func (h *Hub) screenCommand(m cmdMsg) {
	h.mu.Lock()
	defer h.mu.Unlock()
	switch m.Cmd {
	case "generate":
		h.generateLocked(m.Rows, m.Cols, m.Colors, m.Pkt)
	case "start":
		h.startLocked()
	case "toggle":
		if h.phase == "merging" {
			h.paused = !h.paused
		}
	case "step":
		if h.phase == "merging" {
			h.paused = true
			h.mergeStepLocked()
		}
	case "reset":
		h.resetLocked("Repetir: misma matriz, otra vez desordenada y sin repartir.")
	case "speed":
		h.stepMs = clamp(m.Ms, 20, 2000)
	case "work":
		h.workMs = clamp(m.Ms, 10, 500)
	case "forget":
		for _, w := range h.workers {
			if w.conn != nil {
				w.conn.c.Close()
			}
		}
		h.workers = nil
		h.resetLocked("Celulares reasignados. Esperando que se reconecten…")
	}
	h.pushLocked()
}

func (h *Hub) workerCommand(w *worker, m cmdMsg) {
	if m.Cmd != "done" {
		return
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	h.doneLocked(w, m.Job, m.Cells)
	h.pushLocked()
}

func (h *Hub) autoLoop() {
	last := time.Now()
	for {
		time.Sleep(20 * time.Millisecond)
		h.mu.Lock()
		if h.phase == "merging" && !h.paused {
			if time.Since(last) >= time.Duration(h.stepMs)*time.Millisecond {
				last = time.Now()
				h.mergeStepLocked()
				h.pushLocked()
			}
		} else {
			last = time.Now()
		}
		h.mu.Unlock()
	}
}

// ---------- HTTP ----------

func main() {
	addr := flag.String("addr", ":8080", "dirección de escucha")
	key := flag.String("key", "", "clave de la pantalla central (vacío = aleatoria)")
	flag.Parse()
	if *key == "" {
		*key = fmt.Sprintf("%04d", rand.New(rand.NewSource(time.Now().UnixNano())).Intn(10000))
	}

	hub := NewHub()
	go hub.autoLoop()

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(phoneHTML)
	})
	mux.HandleFunc("/screen", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("key") != *key {
			http.Error(w, "clave incorrecta", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(screenHTML)
	})
	mux.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		isScreen := r.URL.Query().Get("role") == "screen"
		id := r.URL.Query().Get("id")
		if isScreen && r.URL.Query().Get("key") != *key {
			http.Error(w, "clave incorrecta", http.StatusForbidden)
			return
		}
		if !isScreen && (id == "" || len(id) > 40) {
			http.Error(w, "id inválido", http.StatusBadRequest)
			return
		}
		c, err := upgrade(w, r)
		if err != nil {
			return
		}
		if isScreen {
			hub.mu.Lock()
			hub.screens[c] = true
			hub.pushLocked()
			hub.mu.Unlock()
			c.loop(func(p []byte) {
				var m cmdMsg
				if json.Unmarshal(p, &m) == nil {
					hub.screenCommand(m)
				}
			})
			hub.mu.Lock()
			delete(hub.screens, c)
			hub.mu.Unlock()
			return
		}
		wk := hub.attach(id, c)
		c.loop(func(p []byte) {
			var m cmdMsg
			if json.Unmarshal(p, &m) == nil {
				hub.workerCommand(wk, m)
			}
		})
		hub.detach(wk, c)
	})

	fmt.Println("Ordenamiento distribuido de cubitos")
	for _, ip := range localIPs() {
		fmt.Printf("  Celulares:         http://%s%s/\n", ip, *addr)
		fmt.Printf("  Pantalla central:  http://%s%s/screen?key=%s\n", ip, *addr, *key)
	}
	log.Fatal(http.ListenAndServe(*addr, mux))
}

func localIPs() []string {
	var out []string
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if ipn, ok := a.(*net.IPNet); ok && !ipn.IP.IsLoopback() && ipn.IP.To4() != nil {
			out = append(out, ipn.IP.String())
		}
	}
	if len(out) == 0 {
		out = []string{"localhost"}
	}
	return out
}
