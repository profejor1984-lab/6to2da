package main

// WebSocket mínimo (RFC 6455) solo con la biblioteca estándar.
// Así el proyecto no necesita internet ni dependencias para compilar.

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

const wsGUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

type wsConn struct {
	c   net.Conn
	br  *bufio.Reader
	wmu sync.Mutex
}

func headerHas(h http.Header, name, val string) bool {
	return strings.Contains(strings.ToLower(strings.Join(h.Values(name), ",")), val)
}

func upgrade(w http.ResponseWriter, r *http.Request) (*wsConn, error) {
	if !headerHas(r.Header, "Connection", "upgrade") || !headerHas(r.Header, "Upgrade", "websocket") {
		http.Error(w, "se esperaba WebSocket", http.StatusBadRequest)
		return nil, errors.New("no es un upgrade a websocket")
	}
	key := r.Header.Get("Sec-WebSocket-Key")
	if key == "" {
		http.Error(w, "falta Sec-WebSocket-Key", http.StatusBadRequest)
		return nil, errors.New("falta Sec-WebSocket-Key")
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		http.Error(w, "hijack no soportado", http.StatusInternalServerError)
		return nil, errors.New("hijack no soportado")
	}
	c, brw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	sum := sha1.Sum([]byte(key + wsGUID))
	accept := base64.StdEncoding.EncodeToString(sum[:])
	resp := "HTTP/1.1 101 Switching Protocols\r\n" +
		"Upgrade: websocket\r\nConnection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: " + accept + "\r\n\r\n"
	if _, err := c.Write([]byte(resp)); err != nil {
		c.Close()
		return nil, err
	}
	return &wsConn{c: c, br: brw.Reader}, nil
}

// write envía un frame (los del servidor van sin máscara).
func (w *wsConn) write(op byte, p []byte) error {
	w.wmu.Lock()
	defer w.wmu.Unlock()
	hdr := []byte{0x80 | op}
	n := len(p)
	switch {
	case n < 126:
		hdr = append(hdr, byte(n))
	case n <= 65535:
		hdr = append(hdr, 126, byte(n>>8), byte(n))
	default:
		b := make([]byte, 8)
		binary.BigEndian.PutUint64(b, uint64(n))
		hdr = append(hdr, 127)
		hdr = append(hdr, b...)
	}
	w.c.SetWriteDeadline(time.Now().Add(2 * time.Second))
	if _, err := w.c.Write(hdr); err != nil {
		return err
	}
	_, err := w.c.Write(p)
	return err
}

func (w *wsConn) read() (op byte, payload []byte, err error) {
	var h [2]byte
	if _, err = io.ReadFull(w.br, h[:]); err != nil {
		return
	}
	op = h[0] & 0x0f
	masked := h[1]&0x80 != 0
	n := uint64(h[1] & 0x7f)
	switch n {
	case 126:
		var b [2]byte
		if _, err = io.ReadFull(w.br, b[:]); err != nil {
			return
		}
		n = uint64(binary.BigEndian.Uint16(b[:]))
	case 127:
		var b [8]byte
		if _, err = io.ReadFull(w.br, b[:]); err != nil {
			return
		}
		n = binary.BigEndian.Uint64(b[:])
	}
	if n > 1<<16 {
		err = errors.New("frame demasiado grande")
		return
	}
	var mask [4]byte
	if masked {
		if _, err = io.ReadFull(w.br, mask[:]); err != nil {
			return
		}
	}
	payload = make([]byte, n)
	if _, err = io.ReadFull(w.br, payload); err != nil {
		return
	}
	if masked {
		for i := range payload {
			payload[i] ^= mask[i%4]
		}
	}
	return
}

// loop lee mensajes hasta que la conexión se cierra o expira (60 s sin actividad;
// las páginas envían un ping de aplicación cada 20 s).
func (w *wsConn) loop(onMsg func([]byte)) {
	defer w.c.Close()
	for {
		w.c.SetReadDeadline(time.Now().Add(60 * time.Second))
		op, p, err := w.read()
		if err != nil {
			return
		}
		switch op {
		case 8:
			w.write(8, nil)
			return
		case 9:
			w.write(10, p)
		case 1:
			onMsg(p)
		}
	}
}
