module bubblecelulares

go 1.21
