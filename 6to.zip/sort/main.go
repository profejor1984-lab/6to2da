package main

import (
	_ "embed"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"net"
	"net/http"
	"sync"
	"time"
)

//go:embed phone.html
var phoneHTML []byte

//go:embed control.html
var controlHTML []byte

// ---------- Estado centralizado ----------

type slot struct {
	id   string  // identificador estable del celular (guardado en su navegador)
	conn *wsConn // nil si está desconectado
	last string  // último mensaje enviado (para no reenviar lo que no cambió)
}

type cellMsg struct {
	T      string `json:"t"`
	Pos    int    `json:"pos"`
	Total  int    `json:"total"`
	Value  *int   `json:"value"`
	Status string `json:"status"`        // idle | compare | swap | noswap | sorted
	Dir    string `json:"dir,omitempty"` // solo en un swap: "right" (el número sale hacia la derecha) o "left"
}

type Hub struct {
	mu       sync.Mutex
	slots    []*slot // índice = posición en el arreglo
	controls map[*wsConn]bool

	arr    []int
	status []string

	// estado de Bubble Sort
	pass, j int
	stage   int // 0: toca comparar, 1: toca resolver (swap / no swap)
	swapped bool
	done    bool
	playing bool
	speedMs int
	comps   int
	swaps   int
	swapJ   int // posición izquierda del swap de este paso, -1 si no hubo
	logLine string
}

func NewHub() *Hub {
	return &Hub{controls: map[*wsConn]bool{}, speedMs: 900, swapJ: -1, logLine: "Esperando celulares…"}
}

func (h *Hub) resetLocked(msg string) {
	h.arr = nil
	h.status = nil
	h.pass, h.j, h.stage = 0, 0, 0
	h.swapped, h.done, h.playing = false, false, false
	h.comps, h.swaps = 0, 0
	h.swapJ = -1
	h.logLine = msg
}

func (h *Hub) loadLocked(vals []int) {
	h.resetLocked("Arreglo cargado. Listo para ordenar.")
	h.arr = vals
	h.status = make([]string, len(vals))
	for i := range h.status {
		h.status[i] = "idle"
	}
	if len(vals) < 2 {
		h.finishLocked()
	}
}

func (h *Hub) finishLocked() {
	for i := range h.status {
		h.status[i] = "sorted"
	}
	h.done, h.playing = true, false
	h.logLine = "¡Arreglo ordenado!"
}

func (h *Hub) generateLocked() {
	n := len(h.slots)
	if n == 0 {
		h.logLine = "No hay celulares conectados."
		return
	}
	max := 99
	if n > max {
		max = n
	}
	for {
		perm := rand.Perm(max)
		vals := make([]int, n)
		sorted := true
		for i := 0; i < n; i++ {
			vals[i] = perm[i] + 1
			if i > 0 && vals[i-1] > vals[i] {
				sorted = false
			}
		}
		if n > 1 && sorted {
			continue // que no salga ya ordenado
		}
		h.loadLocked(vals)
		return
	}
}

// stepLocked avanza UNA etapa: primero comparar, después resolver.
func (h *Hub) stepLocked() {
	if len(h.arr) == 0 || h.done {
		return
	}
	n := len(h.arr)
	j := h.j
	h.swapJ = -1
	if h.stage == 0 {
		for k, s := range h.status {
			if s != "sorted" {
				h.status[k] = "idle"
			}
		}
		h.status[j], h.status[j+1] = "compare", "compare"
		h.comps++
		h.logLine = fmt.Sprintf("Comparar posición %d (%d) con posición %d (%d)", j, h.arr[j], j+1, h.arr[j+1])
		h.stage = 1
	} else {
		if h.arr[j] > h.arr[j+1] {
			a, b := h.arr[j], h.arr[j+1]
			h.arr[j], h.arr[j+1] = b, a
			h.swaps++
			h.swapJ = j
			h.swapped = true
			h.status[j], h.status[j+1] = "swap", "swap"
			h.logLine = fmt.Sprintf("%d > %d → SWAP", a, b)
		} else {
			h.status[j], h.status[j+1] = "noswap", "noswap"
			h.logLine = fmt.Sprintf("%d ≤ %d → sin cambio", h.arr[j], h.arr[j+1])
		}
		h.stage = 0
		h.j++
		if h.j >= n-1-h.pass { // terminó la pasada
			h.status[n-1-h.pass] = "sorted"
			h.pass++
			h.j = 0
			if !h.swapped || h.pass >= n-1 {
				h.finishLocked()
			}
			h.swapped = false
		}
	}
	h.pushLocked(false)
}

// ---------- Envío por WebSocket ----------

func (h *Hub) pushLocked(force bool) {
	n := len(h.slots)
	online := make([]bool, n)
	for k, s := range h.slots {
		online[k] = s.conn != nil
		m := cellMsg{T: "cell", Pos: k, Total: n, Status: "idle"}
		if len(h.arr) == n && n > 0 {
			v := h.arr[k]
			m.Value = &v
			m.Status = h.status[k]
		}
		key, _ := json.Marshal(m) // sin dirección: sirve para detectar si hubo cambios
		if k == h.swapJ {
			m.Dir = "right"
		} else if k == h.swapJ+1 && h.swapJ >= 0 {
			m.Dir = "left"
		}
		out, _ := json.Marshal(m)
		// Solo se envía a quien cambió: los celulares no afectados no reciben nada.
		if s.conn != nil && (force || string(key) != s.last) {
			if err := s.conn.write(1, out); err == nil {
				s.last = string(key)
			}
		}
	}
	snap, _ := json.Marshal(map[string]any{
		"t": "state", "arr": h.arr, "status": h.status, "online": online,
		"playing": h.playing, "speed": h.speedMs, "done": h.done,
		"comps": h.comps, "swaps": h.swaps, "log": h.logLine, "n": n,
	})
	for c := range h.controls {
		if err := c.write(1, snap); err != nil {
			delete(h.controls, c)
			c.c.Close()
		}
	}
}

func (h *Hub) attach(id string, c *wsConn) *slot {
	h.mu.Lock()
	defer h.mu.Unlock()
	var s *slot
	for _, x := range h.slots {
		if x.id == id {
			s = x
			break
		}
	}
	if s == nil {
		s = &slot{id: id}
		h.slots = append(h.slots, s)
		h.resetLocked(fmt.Sprintf("Celular nuevo (posición %d). Hay %d celulares.", len(h.slots)-1, len(h.slots)))
	}
	old := s.conn
	s.conn, s.last = c, ""
	if old != nil {
		old.c.Close()
	}
	h.pushLocked(true)
	return s
}

func (h *Hub) detach(s *slot, c *wsConn) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if s.conn == c {
		s.conn = nil
		h.pushLocked(false)
	}
}

type cmdMsg struct {
	Cmd    string `json:"cmd"`
	Ms     int    `json:"ms"`
	Values []int  `json:"values"`
}

func (h *Hub) command(m cmdMsg) {
	h.mu.Lock()
	defer h.mu.Unlock()
	switch m.Cmd {
	case "generate":
		h.generateLocked()
	case "set":
		seen := map[int]bool{}
		ok := len(m.Values) == len(h.slots) && len(m.Values) > 0
		for _, v := range m.Values {
			if seen[v] {
				ok = false
			}
			seen[v] = true
		}
		if !ok {
			h.logLine = fmt.Sprintf("Valores inválidos: se necesitan %d números distintos.", len(h.slots))
		} else {
			h.loadLocked(append([]int(nil), m.Values...))
		}
	case "step":
		h.playing = false
		h.stepLocked()
	case "play":
		if len(h.arr) == 0 {
			h.generateLocked()
		}
		if !h.done && len(h.arr) > 0 {
			h.playing = true
		}
	case "pause":
		h.playing = false
	case "reset":
		h.resetLocked("Reiniciado.")
	case "speed":
		if m.Ms < 100 {
			m.Ms = 100
		}
		if m.Ms > 5000 {
			m.Ms = 5000
		}
		h.speedMs = m.Ms
	case "forget":
		// Reasigna posiciones: se cierran los celulares y se reconectan solos,
		// quedando en el orden en que lleguen.
		for _, s := range h.slots {
			if s.conn != nil {
				s.conn.c.Close()
			}
		}
		h.slots = nil
		h.resetLocked("Posiciones reasignadas. Esperando celulares…")
	}
	h.pushLocked(false)
}

func (h *Hub) autoLoop() {
	last := time.Now()
	for {
		time.Sleep(25 * time.Millisecond)
		h.mu.Lock()
		if !h.playing {
			last = time.Now()
		} else if time.Since(last) >= time.Duration(h.speedMs)*time.Millisecond {
			last = time.Now()
			h.stepLocked()
		}
		h.mu.Unlock()
	}
}

// ---------- HTTP ----------

func main() {
	addr := flag.String("addr", ":8080", "dirección de escucha")
	key := flag.String("key", "", "clave del panel de control (vacío = aleatoria)")
	flag.Parse()
	if *key == "" {
		*key = fmt.Sprintf("%04d", rand.New(rand.NewSource(time.Now().UnixNano())).Intn(10000))
	}

	hub := NewHub()
	go hub.autoLoop()

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(phoneHTML)
	})
	mux.HandleFunc("/control", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("key") != *key {
			http.Error(w, "clave incorrecta", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(controlHTML)
	})
	mux.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		isControl := r.URL.Query().Get("role") == "control"
		id := r.URL.Query().Get("id")
		if isControl && r.URL.Query().Get("key") != *key {
			http.Error(w, "clave incorrecta", http.StatusForbidden)
			return
		}
		if !isControl && (id == "" || len(id) > 40) {
			http.Error(w, "id inválido", http.StatusBadRequest)
			return
		}
		c, err := upgrade(w, r)
		if err != nil {
			return
		}
		if isControl {
			hub.mu.Lock()
			hub.controls[c] = true
			hub.pushLocked(false)
			hub.mu.Unlock()
			c.loop(func(p []byte) {
				var m cmdMsg
				if json.Unmarshal(p, &m) == nil {
					hub.command(m)
				}
			})
			hub.mu.Lock()
			delete(hub.controls, c)
			hub.mu.Unlock()
			return
		}
		s := hub.attach(id, c)
		c.loop(func([]byte) {}) // los celulares solo reciben (y mandan pings)
		hub.detach(s, c)
	})

	fmt.Println("Servidor Bubble Sort con celulares")
	for _, ip := range localIPs() {
		fmt.Printf("  Celulares:  http://%s%s/\n", ip, *addr)
		fmt.Printf("  Panel:      http://%s%s/control?key=%s\n", ip, *addr, *key)
	}
	log.Fatal(http.ListenAndServe(*addr, mux))
}

func localIPs() []string {
	var out []string
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if ipn, ok := a.(*net.IPNet); ok && !ipn.IP.IsLoopback() && ipn.IP.To4() != nil {
			out = append(out, ipn.IP.String())
		}
	}
	if len(out) == 0 {
		out = []string{"localhost"}
	}
	return out
}
